package tema3_ejerciciosIntegracion;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;

public class Ej2_ServicioPedidoTest {
    private Ej2_ServicioEnvio servicioEnvio;
    private Ej2_ServicioPedido servicioPedido;

    @Before
    public void setUp() {
        // Usar la implementación real del servicio de envío
        servicioEnvio = new Ej2_ServicioEnvio();
        servicioPedido = new Ej2_ServicioPedido(servicioEnvio);
    }

    @Test
    public void testCrearYEnviarPedido() {
        String pedido = "Pedido 123";

        // Llamar al método que crea y envía el pedido
        boolean resultado = servicioPedido.crearYEnviarPedido(pedido);

        // Verificar que el resultado es verdadero, indicando que el pedido fue "enviado"
        assertTrue(resultado);
    }
}