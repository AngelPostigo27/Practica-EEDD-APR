package tema3_ejerciciosIntegracion;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class Ej3_GestorProductosTest {
    private Ej3_BaseDeDatosProductos baseDeDatos;
    private Ej3_GestorProductos gestorProductos;

    @Before
    public void setUp() {
        // Inicializar la base de datos y el gestor de productos
        baseDeDatos = new Ej3_BaseDeDatosProductos();
        gestorProductos = new Ej3_GestorProductos(baseDeDatos);
    }

    @Test
    public void testRegistrarYVerificarProducto() {
        String producto = "Producto 123";

        // Registrar el producto
        gestorProductos.registrarProducto(producto);

        // Verificar que el producto está registrado
        assertTrue(gestorProductos.productoRegistrado(producto));
    }

    @Test
    public void testVerificarProductoNoRegistrado() {
        String producto = "Producto 456";

        // Verificar que el producto no está registrado antes de registrarlo
        assertFalse(gestorProductos.productoRegistrado(producto));
    }
}