package tema3_ejerciciosIntegracion;

import org.junit.Test;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class Ej4_ServicioOrdenesTest {

    @Test
    public void testProcesarOrdenConPagoExitoso() {
        // Inicializar el servicio de pagos y el servicio de órdenes
        Ej4_ServicioPagos servicioPagos = new Ej4_ServicioPagos();
        Ej4_ServicioOrdenes servicioOrdenes = new Ej4_ServicioOrdenes(servicioPagos);

        double montoOrden = 500.0; // Monto de la orden

        // Procesar la orden
        boolean resultado = servicioOrdenes.procesarOrden(montoOrden);

        // Verificar que la orden se procesó correctamente
        assertTrue(resultado);
    }

    @Test
    public void testProcesarOrdenConPagoRechazado() {
        // Inicializar el servicio de pagos y el servicio de órdenes
        Ej4_ServicioPagos servicioPagos = new Ej4_ServicioPagos();
        Ej4_ServicioOrdenes servicioOrdenes = new Ej4_ServicioOrdenes(servicioPagos);

        double montoOrden = 1500.0; // Monto de la orden mayor que el saldo

        // Procesar la orden
        boolean resultado = servicioOrdenes.procesarOrden(montoOrden);

        // Verificar que la orden no se procesó debido a un pago rechazado
        assertFalse(resultado);
    }
}